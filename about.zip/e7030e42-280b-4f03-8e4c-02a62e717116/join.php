<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/gif/png" href="img/z.png">
        <title>Join</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
        <link href="style.css" rel="stylesheet">
</head>
<?php
$result_str = $result = '';
if (isset($_POST['unit-submit'])) {
    $units = $_POST['units'];
    if (!empty($units)) {
        $result = calculate_bill($units);
        $result_str = 'Total amount of ' . $units . ' - ' . $result;
    }
}
/**
 * To calculate electricity bill as per unit cost**/
function calculate_bill($units) {
 $unit_cost_first = 9;
    $unit_cost_second = 12;

    $unit_cost_fourth = 15;

    if($units <= 50) {
        $bill = $units * $unit_cost_first;
    }
    else if($units > 50 && $units <= 100) {
        //$temp = 50 * $unit_cost_first;
}
 else if($units > 50 && $units <= 100) {
        //$temp = 50 * $unit_cost_first;
        //$remaining_units = $units - 50;
        //$bill = $temp + ($remaining_units * $unit_cost_second);
$bill = $units * $unit_cost_second;
    }

    else {
        //$temp = (50 * 9) + (100 * $unit_cost_second);
        //$remaining_units = $units - 250;
       // $bill = $temp + ($remaining_units * $unit_cost_fourth);
$bill = $units * $unit_cost_fourth;
}
return number_format((float)$bill, 2, '.', '');
}

?>
<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-md navbar-light bg-light sticky-top">
<div class="container-fluid">
        <h5> ELECTRICITY BILL CALCI </h5>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
                <span class="navbar-toggler-icon"></span>
</button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                                <a class="nav-link" href="index1.html">Home</a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="about.html">About Us</a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="services.html">Services</a>
                        </li>
                        <li class="nav-item">
<a class="nav-link active" href="join.html">Generate Bill</a>
                        </li>
                </ul>
        </div>
</div>
</nav>
<!-- End Navigation -->

<br><br>

<!--Join Us Form-->
<button type="button" class="btn btn-lg btn-block btn-outline-primary col-8 offset-2" data-toggle="collapse" data-target="#join"><h1 class="display-4">Click this to</h1><h1 class="display-4"> calculate your bill amount.</h1></button>

  
<div id="join" class="collapse">
<div class="container">
<form action="#" method="post" id="join-us">
        <div class="form-group row">
                <div class="col-8 offset-2">
<div id="page-wrap">
                <h1>Php - Calculate Electricity Bill</h1>

                <form action="" method="post" id="quiz-form">
                <input type="number" name="units" id="units" placeholder="Pleas$
                <input type="submit" name="unit-submit" id="unit-submit" value=$
                </form>
<div>
                    <?php echo '<br />'  $result_str; ?>
                </div>
        </div>

                                </div>
        </div>
</form>
</div>
</div>
<!--End Join Us Form-->

<br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<!--- Footer -->
<footer>
<div class="container-fluid padding">
<div class="row text-center font-weight-bold">

<div class="col-sm-10 offset-sm-1 col-md-4 offset-md-0">
        <hr class="light">
        <h5>Developer_Vaishali</h5>
        <hr class="light">>
</div>
<div class="col-sm-10 offset-sm-1 col-md-4 offset-md-0">
        <hr class="light">
        <h5> E_B_C </h5>
        <hr class="light">
        <p><a href="mailto: info@zap.com">info.EBC@123</a></p>
</div>
<div class="col-sm-10 offset-sm-1 col-md-4 offset-md-0">
        <hr class="light">
        <h5>Contact Us</h5>
        <hr class="light">
        <p>Mobile: 9999999999</p>

</div>
<div class="col-12">
        <hr class="light-100">
        <h5>&copy; APSPDCL</h5>
</div>

</div>
</div>
</footer>
<!--- End Footer -->

</body>
</html>

